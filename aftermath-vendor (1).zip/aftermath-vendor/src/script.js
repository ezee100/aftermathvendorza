console.log("Aftermath Vendor ZA loaded successfully.");

// Optional: Track Buy button clicks (for analytics)
document.querySelectorAll(".buy-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    console.log(`Buy button clicked: ${btn.textContent}`);
  });
});
